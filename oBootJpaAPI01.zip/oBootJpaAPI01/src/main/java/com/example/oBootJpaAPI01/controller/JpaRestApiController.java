package com.example.oBootJpaAPI01.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.oBootJpaAPI01.domain.Member;
import com.example.oBootJpaAPI01.service.MemberService;

import lombok.RequiredArgsConstructor;
//Controller + ResponseBody
@RestController
@RequiredArgsConstructor	// @AutoWired 생성자 생성
public class JpaRestApiController {

	private final MemberService memberService;
	
	@GetMapping("/RestApi/v1/members")
	public List<Member> membersV1(){
		return memberService.getListAllMember();
	}
}

