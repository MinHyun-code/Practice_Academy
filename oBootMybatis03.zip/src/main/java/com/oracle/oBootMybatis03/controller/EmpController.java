package com.oracle.oBootMybatis03.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.oracle.oBootMybatis03.model.Dept;
import com.oracle.oBootMybatis03.model.Emp;
import com.oracle.oBootMybatis03.service.EmpService;
import com.oracle.oBootMybatis03.service.Paging;

@Controller
public class EmpController {
	@Autowired
	private EmpService es;
	
	@RequestMapping(value="list")
	public String list(Emp emp, String currentPage, Model model) {
		System.out.println("EmpController Start list..." );
		int total = es.total();   // Emp Count -> 19
		System.out.println("EmpController total=>" + total);
		System.out.println("currentPage=>" + currentPage);
		//                     14     NULL(0,1....)
		Paging pg = new Paging(total, currentPage);
		emp.setStart(pg.getStart());   // 시작시 1
		emp.setEnd(pg.getEnd());       // 시작시 10 
		List<Emp> listEmp = es.listEmp(emp);
		System.out.println("EmpController list listEmp.size()=>" + listEmp.size());
		model.addAttribute("total", total);
		model.addAttribute("listEmp",listEmp);
		model.addAttribute("pg",pg);

		return "list";
	}
	
	@GetMapping(value="detail")
	public String detail(HttpServletRequest request , int empno, Model model) {
		System.out.println("EmpController Start detail..." );
		Emp emp = es.detail(empno);
		model.addAttribute("emp",emp);
		
		return "detail";
	}
	@GetMapping(value="updateForm")
	public String updateForm(int empno,Model model) {
		System.out.println("EmpController Start updateForm..." );
		Emp emp = es.detail(empno);
		model.addAttribute("emp",emp);

		return "updateForm";
	}
	// @RequestMapping(value="update" , method=RequestMethod.POST)
    @PostMapping(value="update")
    public String update(Emp emp, Model model) {
		int k = es.update(emp);
		System.out.println("es.update(emp) k-->"+k);
		model.addAttribute("kkk",k);   // Test Controller간 Data 전달
		model.addAttribute("kk3","Message Test");   // Test Controller간 Data 전달
		//return "redirect:list";   
		return "forward:list";   
    }
    
	@RequestMapping(value="writeForm")
	public String writeForm(Model model) {
	// 	Emp emp = null;
		List<Emp> list = es.listManager();
		System.out.println("EmpController writeForm list.size->"+list.size());
		model.addAttribute("empMngList",list);   // emp Manager List
		List<Dept> deptList = es.deptSelect();
		model.addAttribute("deptList", deptList); // dept
		return "writeForm";
	}
  
//	@RequestMapping(value="write" ,  method=RequestMethod.POST)
//	public String write(Emp emp, Model model) {
//		System.out.println("EmpController Start write..." );
//		//System.out.println("emp.getHiredate->"+emp.getHiredate());
//		// Service, Dao , Mapper명 까지 -> insert
//		int result = es.insert(emp);
//		if (result > 0) return "redirect:list";
//		else {
//			model.addAttribute("msg","입력 실패 확인해 보세요");
//			return "forward:writeForm";
//		}
//	    	
//	}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    
}
