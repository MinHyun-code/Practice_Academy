package com.oracle.oBootMybatis03.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Dept {
	private int    deptno;
	private String dname;
	private String loc;
	
}
